<?php
namespace App\Models;
use DB;
use Illuminate\Database\Eloquent\Model;

class Banner extends Model{
    protected $table = 'banners';

    protected $guarded = ['id'];

}
